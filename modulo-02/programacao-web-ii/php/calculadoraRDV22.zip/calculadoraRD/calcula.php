
<?php
$resultado = "";

if (isset($_POST['calcular'])) {
    $num1 = $_POST['num1'];
    $num2 = $_POST['num2'];
    $operacao = $_POST['operacao'];

    switch ($operacao) {
        case "somar":
            $resultado = $num1 + $num2;
            break;

        case "subtrair":
            $resultado = $num1 - $num2;
            break;

        case "multiplicar":
            $resultado = $num1 * $num2;
            break;

        case "dividir":
            if ($num2 != 0) {
                $resultado = $num1 / $num2;
            } else {
                $resultado = "Não é possível dividir por zero!";
            }
            break;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Calculadora PHP</title>

    <style>
        body {
            background: #222;
            font-family: Arial;
            text-align: center;
            color: white;
        }

        .calculadora {
            background: #333;
            width: 300px;
            margin: 100px auto;
            padding: 25px;
            border-radius: 15px;
        }

        input, select, button {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            box-sizing: border-box;
        }

        button {
            background: #00b894;
            color: white;
            border: none;
            cursor: pointer;
        }

        h2 {
            color: #00b894;
        }
    </style>
</head>

<body>

<div class="calculadora">

    <h2>Calculadora PHP</h2>

    <form method="POST">

        <input type="number" step="any" name="num1"
        placeholder="Primeiro número" required>

        <select name="operacao">
            <option value="somar">Adição (+)</option>
            <option value="subtrair">Subtração (-)</option>
            <option value="multiplicar">Multiplicação (*)</option>
            <option value="dividir">Divisão (/)</option>
        </select>

        <input type="number" step="any" name="num2"
        placeholder="Segundo número" required>

        <button type="submit" name="calcular">
            Calcular
        </button>

    </form>

    <?php if ($resultado !== ""): ?>
        <h3>Resultado: <?= htmlspecialchars((string)$resultado) ?></h3>
    <?php endif; ?>

</div>

</body>
</html>
