<?php
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['sucesso' => false, 'mensagem' => 'Método inválido.']);
    exit;
}

$num1 = $_POST['num1'] ?? '';
$num2 = $_POST['num2'] ?? '';
$operacao = $_POST['operacao'] ?? '';

if (!is_numeric($num1) || !is_numeric($num2)) {
    echo json_encode(['sucesso' => false, 'mensagem' => 'Insira apenas números válidos.']);
    exit;
}

$n1 = (float) $num1;
$n2 = (float) $num2;

switch ($operacao) {
    case 'soma':
        echo json_encode(['sucesso' => true, 'valor' => $n1 + $n2]);
        break;
    case 'subtracao':
        echo json_encode(['sucesso' => true, 'valor' => $n1 - $n2]);
        break;
    case 'multiplicacao':
        echo json_encode(['sucesso' => true, 'valor' => $n1 * $n2]);
        break;
    case 'divisao':
        if ($n2 == 0.0) {
            echo json_encode(['sucesso' => false, 'mensagem' => 'Erro: Divisão por zero não permitida.']);
        } else {
            echo json_encode(['sucesso' => true, 'valor' => $n1 / $n2]);
        }
        break;
    default:
        echo json_encode(['sucesso' => false, 'mensagem' => 'Operação inválida.']);
}
