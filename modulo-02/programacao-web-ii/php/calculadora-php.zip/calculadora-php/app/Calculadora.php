<?php

class Calculadora {
    public static function calcular($num1, $num2, $operacao): array {
        if (!is_numeric($num1) || !is_numeric($num2)) {
            return ['sucesso' => false, 'mensagem' => 'Insira apenas números válidos.'];
        }

        $n1 = (float) $num1;
        $n2 = (float) $num2;

        switch ($operacao) {
            case 'soma':
                return ['sucesso' => true, 'valor' => $n1 + $n2];
            case 'subtracao':
                return ['sucesso' => true, 'valor' => $n1 - $n2];
            case 'multiplicacao':
                return ['sucesso' => true, 'valor' => $n1 * $n2];
            case 'divisao':
                if ($n2 == 0.0) {
                    return ['sucesso' => false, 'mensagem' => 'Erro: Divisão por zero não permitida.'];
                }
                return ['sucesso' => true, 'valor' => $n1 / $n2];
            default:
                return ['sucesso' => false, 'mensagem' => 'Operação inválida.'];
        }
    }
}
