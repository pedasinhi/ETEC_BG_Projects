<?php
require_once __DIR__ . '/app/Calculadora.php';

$num1 = $_POST['num1'] ?? '';
$num2 = $_POST['num2'] ?? '';
$operacao = $_POST['operacao'] ?? 'soma';
$resposta = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $resposta = Calculadora::calcular($num1, $num2, $operacao);
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora PHP</title>
    <link rel="stylesheet" href="public/style.css">
</head>
<body>

<div class="container">
    <h2>Calculadora PHP</h2>

    <form method="POST" action="">
        <div class="form-group">
            <label for="num1">Número 1:</label>
            <input type="number" step="any" name="num1" id="num1" required value="<?= htmlspecialchars($num1) ?>">
        </div>

        <div class="form-group">
            <label for="operacao">Operação:</label>
            <select name="operacao" id="operacao">
                <option value="soma" <?= $operacao === 'soma' ? 'selected' : '' ?>>Soma (+)</option>
                <option value="subtracao" <?= $operacao === 'subtracao' ? 'selected' : '' ?>>Subtração (-)</option>
                <option value="multiplicacao" <?= $operacao === 'multiplicacao' ? 'selected' : '' ?>>Multiplicação (×)</option>
                <option value="divisao" <?= $operacao === 'divisao' ? 'selected' : '' ?>>Divisão (÷)</option>
            </select>
        </div>

        <div class="form-group">
            <label for="num2">Número 2:</label>
            <input type="number" step="any" name="num2" id="num2" required value="<?= htmlspecialchars($num2) ?>">
        </div>

        <button type="submit">Calcular</button>
    </form>

    <?php if ($resposta !== null): ?>
        <?php if ($resposta['sucesso']): ?>
            <div class="alert success">Resultado: <?= $resposta['valor'] ?></div>
        <?php else: ?>
            <div class="alert error"><?= htmlspecialchars($resposta['mensagem']) ?></div>
        <?php endif; ?>
    <?php endif; ?>
</div>

</body>
</html>
