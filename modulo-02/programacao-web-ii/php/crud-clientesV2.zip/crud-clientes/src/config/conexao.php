<?php

try {
    $conexao = new mysqli('localhost', 'root', '');
    $conexao->set_charset('utf8mb4');

    $conexao->query('CREATE DATABASE IF NOT EXISTS crud_php CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
    $conexao->select_db('crud_php');

    $conexao->query("CREATE TABLE IF NOT EXISTS usuarios (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        telefone VARCHAR(20) NOT NULL DEFAULT ''
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Throwable $erro) {
    http_response_code(503);
    $titulo = 'Banco de dados indisponível';
    $base = '../../';
    require __DIR__ . '/../includes/cabecalho.php';
    ?>
    <h1>Não foi possível acessar o banco de dados</h1>
    <p>Verifique se o MySQL está iniciado no XAMPP. O projeto cria o banco <strong>crud_php</strong> e a tabela <strong>usuarios</strong> automaticamente, desde que o usuário do MySQL tenha permissão.</p>
    <div class="notice">
        <strong>Detalhes:</strong>
        <?= htmlspecialchars($erro->getMessage(), ENT_QUOTES, 'UTF-8') ?>
    </div>
    <p>Se a criação automática estiver bloqueada, importe o arquivo <strong>database/schema.sql</strong> pelo phpMyAdmin ou peça ajuda ao responsável pelo computador.</p>
    <?php
    require __DIR__ . '/../includes/rodape.php';
    exit;
}
