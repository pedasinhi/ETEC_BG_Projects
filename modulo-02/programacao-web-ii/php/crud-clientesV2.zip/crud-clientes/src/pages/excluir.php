<?php
require __DIR__ . '/../config/conexao.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$usuario = null;
$mensagem = '';

if ($id && $id > 0) {
    try {
        $stmt = $conexao->prepare('SELECT id, nome FROM usuarios WHERE id = ?');
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $usuario = $stmt->get_result()->fetch_assoc();
    } catch (mysqli_sql_exception $erro) {
        $mensagem = 'Não foi possível consultar este cliente.';
    }
}

if ($usuario && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirmar'])) {
    try {
        $stmt = $conexao->prepare('DELETE FROM usuarios WHERE id = ?');
        $stmt->bind_param('i', $id);
        $stmt->execute();
        header('Location: listar.php?excluido=1');
        exit;
    } catch (mysqli_sql_exception $erro) {
        $mensagem = 'Não foi possível excluir o cliente. Tente novamente.';
    }
}

$titulo = 'Excluir cliente';
require __DIR__ . '/../includes/cabecalho.php';
?>
<div class="form-card">
    <h1>Excluir cliente</h1>

    <?php if ($mensagem !== ''): ?>
        <div class="notice" role="alert"><?= htmlspecialchars($mensagem, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>

    <?php if (!$usuario): ?>
        <p>Cliente não encontrado. Escolha um cliente na lista para excluir.</p>
        <a class="button button-outline" href="listar.php">Ver clientes</a>
    <?php else: ?>
        <p>Deseja excluir <strong><?= htmlspecialchars($usuario['nome'], ENT_QUOTES, 'UTF-8') ?></strong>? Esta ação não pode ser desfeita.</p>

        <form method="post">
            <div class="actions">
                <button class="button" type="submit" name="confirmar" value="1">Excluir cliente</button>
                <a class="button button-outline" href="listar.php">Cancelar</a>
            </div>
        </form>
    <?php endif; ?>
</div>
<?php require __DIR__ . '/../includes/rodape.php'; ?>
