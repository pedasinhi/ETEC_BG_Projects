<?php
require __DIR__ . '/../config/conexao.php';

$nome = '';
$email = '';
$telefone = '';
$mensagem = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telefone = trim($_POST['telefone'] ?? '');

    if ($nome === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $mensagem = 'Informe um nome e um e-mail válido.';
    } elseif (preg_match_all('/./u', $nome) > 100 || strlen($email) > 100 || preg_match_all('/./u', $telefone) > 20) {
        $mensagem = 'Confira o tamanho dos campos preenchidos.';
    } else {
        try {
            $stmt = $conexao->prepare('INSERT INTO usuarios (nome, email, telefone) VALUES (?, ?, ?)');
            $stmt->bind_param('sss', $nome, $email, $telefone);
            $stmt->execute();
            header('Location: listar.php?cadastrado=1');
            exit;
        } catch (mysqli_sql_exception $erro) {
            $mensagem = 'Não foi possível cadastrar o cliente. Tente novamente.';
        }
    }
}

$titulo = 'Cadastrar cliente';
require __DIR__ . '/../includes/cabecalho.php';
?>
<div class="form-card">
    <h1>Cadastrar cliente</h1>
    <p class="muted">Preencha os dados abaixo.</p>

    <?php if ($mensagem !== ''): ?>
        <div class="notice" role="alert"><?= htmlspecialchars($mensagem, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>

    <form method="post">
        <div class="field">
            <label for="nome">Nome</label>
            <input id="nome" name="nome" type="text" maxlength="100" value="<?= htmlspecialchars($nome, ENT_QUOTES, 'UTF-8') ?>" required>
        </div>
        <div class="field">
            <label for="email">E-mail</label>
            <input id="email" name="email" type="email" maxlength="100" value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>" required>
        </div>
        <div class="field">
            <label for="telefone">Telefone</label>
            <input id="telefone" name="telefone" type="tel" maxlength="20" value="<?= htmlspecialchars($telefone, ENT_QUOTES, 'UTF-8') ?>">
        </div>
        <div class="actions">
            <button class="button" type="submit">Cadastrar</button>
            <a class="button button-outline" href="listar.php">Cancelar</a>
        </div>
    </form>
</div>
<?php require __DIR__ . '/../includes/rodape.php'; ?>
