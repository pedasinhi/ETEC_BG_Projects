<?php
require __DIR__ . '/../config/conexao.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$usuario = null;
$mensagem = '';

if ($id && $id > 0) {
    try {
        $stmt = $conexao->prepare('SELECT id, nome, email, telefone FROM usuarios WHERE id = ?');
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $usuario = $stmt->get_result()->fetch_assoc();
    } catch (mysqli_sql_exception $erro) {
        $mensagem = 'Não foi possível consultar este cliente.';
    }
}

if ($usuario && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario['nome'] = trim($_POST['nome'] ?? '');
    $usuario['email'] = trim($_POST['email'] ?? '');
    $usuario['telefone'] = trim($_POST['telefone'] ?? '');

    if ($usuario['nome'] === '' || !filter_var($usuario['email'], FILTER_VALIDATE_EMAIL)) {
        $mensagem = 'Informe um nome e um e-mail válido.';
    } elseif (preg_match_all('/./u', $usuario['nome']) > 100 || strlen($usuario['email']) > 100 || preg_match_all('/./u', $usuario['telefone']) > 20) {
        $mensagem = 'Confira o tamanho dos campos preenchidos.';
    } else {
        try {
            $stmt = $conexao->prepare('UPDATE usuarios SET nome = ?, email = ?, telefone = ? WHERE id = ?');
            $stmt->bind_param('sssi', $usuario['nome'], $usuario['email'], $usuario['telefone'], $id);
            $stmt->execute();
            header('Location: listar.php?atualizado=1');
            exit;
        } catch (mysqli_sql_exception $erro) {
            $mensagem = 'Não foi possível atualizar o cliente. Tente novamente.';
        }
    }
}

$titulo = 'Editar cliente';
require __DIR__ . '/../includes/cabecalho.php';
?>
<div class="form-card">
    <h1>Editar cliente</h1>

    <?php if ($mensagem !== ''): ?>
        <div class="notice" role="alert"><?= htmlspecialchars($mensagem, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>

    <?php if (!$usuario): ?>
        <p>Cliente não encontrado. Escolha um cliente na lista para editar.</p>
        <a class="button button-outline" href="listar.php">Ver clientes</a>
    <?php else: ?>

        <form method="post">
            <div class="field">
                <label for="nome">Nome</label>
                <input id="nome" name="nome" type="text" maxlength="100" value="<?= htmlspecialchars($usuario['nome'], ENT_QUOTES, 'UTF-8') ?>" required>
            </div>
            <div class="field">
                <label for="email">E-mail</label>
                <input id="email" name="email" type="email" maxlength="100" value="<?= htmlspecialchars($usuario['email'], ENT_QUOTES, 'UTF-8') ?>" required>
            </div>
            <div class="field">
                <label for="telefone">Telefone</label>
                <input id="telefone" name="telefone" type="tel" maxlength="20" value="<?= htmlspecialchars($usuario['telefone'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
            </div>
            <div class="actions">
                <button class="button" type="submit">Salvar alterações</button>
                <a class="button button-outline" href="listar.php">Cancelar</a>
            </div>
        </form>
    <?php endif; ?>
</div>
<?php require __DIR__ . '/../includes/rodape.php'; ?>
