<?php
require __DIR__ . '/../config/conexao.php';

$pesquisa = $_GET['pesquisa'] ?? '';
$pesquisa = is_string($pesquisa) ? trim($pesquisa) : '';
$usuarios = [];
$mensagem = '';
$erroCarregamento = false;

if (isset($_GET['cadastrado'])) {
    $mensagem = 'Cliente cadastrado com sucesso.';
} elseif (isset($_GET['atualizado'])) {
    $mensagem = 'Cliente atualizado com sucesso.';
} elseif (isset($_GET['excluido'])) {
    $mensagem = 'Cliente excluído com sucesso.';
}

try {
    if ($pesquisa !== '') {
        $termo = '%' . $pesquisa . '%';
        $stmt = $conexao->prepare('SELECT id, nome, email, telefone FROM usuarios
                                  WHERE nome LIKE ? OR email LIKE ? OR telefone LIKE ?
                                  ORDER BY id DESC');
        $stmt->bind_param('sss', $termo, $termo, $termo);
        $stmt->execute();
        $resultado = $stmt->get_result();
    } else {
        $resultado = $conexao->query('SELECT id, nome, email, telefone FROM usuarios ORDER BY id DESC');
    }

    $usuarios = $resultado->fetch_all(MYSQLI_ASSOC);
} catch (mysqli_sql_exception $erro) {
    $mensagem = 'Não foi possível carregar os clientes.';
    $erroCarregamento = true;
}

$titulo = 'Clientes';
require __DIR__ . '/../includes/cabecalho.php';
?>
<div class="page-heading">
    <h1>Clientes cadastrados</h1>
    <a class="button" href="cadastrar.php">Novo cliente</a>
</div>

<form class="search-form" method="get" action="listar.php" role="search">
    <div class="field">
        <label for="pesquisa">Pesquisar clientes</label>
        <input type="search" id="pesquisa" name="pesquisa" placeholder="Nome, e-mail ou telefone" maxlength="100" value="<?= htmlspecialchars($pesquisa, ENT_QUOTES, 'UTF-8') ?>">
    </div>
    <button class="button" type="submit">Buscar</button>
    <?php if ($pesquisa !== ''): ?>
        <a class="button button-outline" href="listar.php">Limpar</a>
    <?php endif; ?>
</form>

<?php if ($mensagem !== ''): ?>
    <div class="notice" role="status"><?= htmlspecialchars($mensagem, ENT_QUOTES, 'UTF-8') ?></div>
<?php endif; ?>

<?php if ($erroCarregamento): ?>
    <p class="muted">Tente atualizar a página.</p>
<?php elseif ($usuarios): ?>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>E-mail</th>
                    <th>Telefone</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($usuarios as $usuario): ?>
                    <tr>
                        <td><?= (int) $usuario['id'] ?></td>
                        <td><?= htmlspecialchars($usuario['nome'], ENT_QUOTES, 'UTF-8') ?></td>
                        <td><?= htmlspecialchars($usuario['email'], ENT_QUOTES, 'UTF-8') ?></td>
                        <td><?= htmlspecialchars($usuario['telefone'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
                        <td class="row-actions">
                            <a href="editar.php?id=<?= (int) $usuario['id'] ?>">Editar</a>
                            <a href="excluir.php?id=<?= (int) $usuario['id'] ?>">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php else: ?>
    <div class="empty-state">
        <?php if ($pesquisa !== ''): ?>
            <p>Nenhum cliente encontrado para "<?= htmlspecialchars($pesquisa, ENT_QUOTES, 'UTF-8') ?>".</p>
            <a class="button button-outline" href="listar.php">Ver todos os clientes</a>
        <?php else: ?>
            <p>Nenhum cliente cadastrado ainda.</p>
            <a class="button" href="cadastrar.php">Cadastrar primeiro cliente</a>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php require __DIR__ . '/../includes/rodape.php'; ?>
