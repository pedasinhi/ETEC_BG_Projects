<?php
$titulo = $titulo ?? 'Clientes';
$base = $base ?? '../../';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($titulo, ENT_QUOTES, 'UTF-8') ?> | CRUD de Clientes</title>
    <link rel="stylesheet" href="<?= $base ?>src/css/style.css">
</head>
<body>
    <header class="site-header">
        <div class="container header-content">
            <a class="brand" href="<?= $base ?>index.php">CRUD de Clientes</a>
            <nav aria-label="Menu principal">
                <a href="<?= $base ?>index.php">Início</a>
                <a href="<?= $base ?>src/pages/listar.php">Clientes</a>
                <a href="<?= $base ?>src/pages/cadastrar.php">Cadastrar</a>
            </nav>
        </div>
    </header>
    <main class="container">
