<?php
$titulo = 'Início';
$base = '';
require __DIR__ . '/src/includes/cabecalho.php';
?>
<h1>Gerenciamento de clientes</h1>
<div class="actions">
    <a class="button" href="src/pages/cadastrar.php">Cadastrar cliente</a>
    <a class="button button-outline" href="src/pages/listar.php">Ver clientes</a>
</div>
<?php require __DIR__ . '/src/includes/rodape.php'; ?>
